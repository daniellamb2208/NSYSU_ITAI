#!/bin/bash

sudo apt install update

sudo apt install python3 python3-pip python-dev libsdl-image1.2-dev libsdl-mixer1.2-dev \
    libsdl-ttf2.0-dev libsdl1.2-dev libsmpeg-dev python-numpy subversion libportmidi-dev \
    ffmpeg libswscale-dev libavformat-dev libavcodec-dev libfreetype6-dev -y

pip3 install pygame
